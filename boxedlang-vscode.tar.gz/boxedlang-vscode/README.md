# BoxedLANG syntax highlighting (VS Code / Code-OSS)

## Install (unpacked, no build step needed)

1. Copy this whole folder into your extensions directory:
   - VS Code:  `~/.vscode/extensions/boxedlang-0.0.1`
   - Code-OSS/VSCodium: `~/.vscode-oss/extensions/boxedlang-0.0.1`
     (check `~/.config/Code - OSS/` if that path doesn't exist for you)
2. Restart the editor. `.bx` files should now be detected as "BoxedLANG"
   (shown in the bottom-right language picker).

## Force the exact reference colors

Grammar scopes alone only get colored according to your current color
theme, same limitation as micro. To pin the exact palette regardless of
theme, add this to your `settings.json` (Ctrl+Shift+P -> "Preferences:
Open User Settings (JSON)"):

```json
"editor.tokenColorCustomizations": {
    "textMateRules": [
        { "scope": "source.bx",
          "settings": { "foreground": "#7a97b2" } },
        { "scope": "keyword.control.bx",
          "settings": { "foreground": "#84b29c" } },
        { "scope": "variable.parameter.bx",
          "settings": { "foreground": "#bcece1" } },
        { "scope": "punctuation.separator.pipe.bx",
          "settings": { "foreground": "#885361" } },
        { "scope": "comment.line.double-slash.bx",
          "settings": { "foreground": "#8264a4", "fontStyle": "italic" } }
    ]
}
```

This layers on top of whatever theme you're already using (like the
`include "monokai"` trick in the micro colorscheme) - it does not
replace your theme, it only overrides these five scopes.
